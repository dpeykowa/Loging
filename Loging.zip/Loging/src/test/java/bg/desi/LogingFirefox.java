package bg.desi;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.By;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class LogingFirefox {
public static WebDriver driver;
	
	@Before
	public void startUp2 (){
		System.setProperty("webdriver.gecko.driver", "F:\\Installers\\selenium\\geckodriver.exe");
		driver = new FirefoxDriver();
		
		driver.get("https://sumup.com/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}
	
	@After
	public void tearDown(){
		driver.quit();
	}

	@Test
	public void logging() {
		 driver.findElement(By.linkText("��� ���������� ����")).click();
		 driver.findElement(By.linkText("����")).click();
		 driver.findElement(By.id("username")).click();
		 driver.findElement(By.id("username")).sendKeys("dpeykowa@mail.bg");
		 driver.findElement(By.id("password")).click();
		 driver.findElement(By.id("password")).sendKeys("Password123!");
		 driver.findElement(By.xpath("//*[contains(@type,'submit')]")).click();
		 driver.getTitle().equalsIgnoreCase("�������");
	}

}
